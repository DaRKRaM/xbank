# kpt-grabar-cpt-frontend
Plugin de ejemplo para el artículo [Grabar Custom Post Type desde el frontend de WordPress](https://kungfupress.com/?p=303) del blog de KungFuPress
